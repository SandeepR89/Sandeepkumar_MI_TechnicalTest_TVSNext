﻿using System;
using System.IO;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using Serilog;

namespace MediaInteractiveaAPI.Services.Common
{
    public class TraceLog
    {
        private static ILogger _logger;

        public static void LogActivity(string activityType, RouteData routeData, string serviceName)
        {
            if (_logger == null)
            {
                var configuration = new ConfigurationBuilder()
                                    .AddJsonFile(Environment.CurrentDirectory + "/appsettings.json", optional: false, reloadOnChange: true)
                                    .Build();

                _logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();
            }

            if (activityType.Contains(Constants.controllerIn))
            {
                _logger.Information("------------------------------" + Convert.ToString(routeData.Values["controller"]) + " - " + Convert.ToString(routeData.Values["action"]) + " - START------------------------------");
            }
            else if (activityType.Contains(Constants.serviceIn))
            {
                _logger.Information("------------------------------" + serviceName + " - START------------------------------");
                _logger.Information("Date: " + DateTime.Now);
               
            }

            if (activityType.Contains(Constants.controllerOut))
            {
                _logger.Information("------------------------------" + Convert.ToString(routeData.Values["controller"]) + " - " + Convert.ToString(routeData.Values["action"]) + " - END------------------------------");
            }

            if (activityType.Contains(Constants.serviceOut))
            {
                _logger.Information("------------------------------" + serviceName + " - END------------------------------");
            }
        }

        public static void LogError(string serviceName, Exception ex)
        {
            if (_logger == null)
            {
                var configuration = new ConfigurationBuilder()
                                    .AddJsonFile(Environment.CurrentDirectory + "/appsettings.json", optional: false, reloadOnChange: true)
                                    .Build();

                _logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();
            }

            JObject jObject = JObject.Parse(File.ReadAllText(Environment.CurrentDirectory + "/appsettings.json"));

            string restrictedToMinimumLevel = (string)jObject["Serilog"]["WriteTo"][0]["Args"]["restrictedToMinimumLevel"];

            if (restrictedToMinimumLevel == "Error")
            {
                _logger.Error("------------------------------" + serviceName + " - START------------------------------");
                _logger.Error("Date: " + DateTime.Now);
                _logger.Error("Data: " + ex.Data);
                _logger.Error("InnerException: " + ex.InnerException);
                _logger.Error("Message: " + ex.Message);
                _logger.Error("StackTrace: " + ex.StackTrace);
                _logger.Error("------------------------------" + serviceName + " - END------------------------------");
            }
            else
            {
                _logger.Error("Data: " + ex.Data);
                _logger.Error("InnerException: " + ex.InnerException);
                _logger.Error("Message: " + ex.Message);
                _logger.Error("StackTrace: " + ex.StackTrace);
            }
        }
    }
}
