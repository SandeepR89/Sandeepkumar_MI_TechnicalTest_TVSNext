﻿namespace MediaInteractiveaAPI.Services.Common
{
    public class SPConstants
    {
        public const string getAllEmployee = "MI_GetAllEmployee";
      
    }
}
