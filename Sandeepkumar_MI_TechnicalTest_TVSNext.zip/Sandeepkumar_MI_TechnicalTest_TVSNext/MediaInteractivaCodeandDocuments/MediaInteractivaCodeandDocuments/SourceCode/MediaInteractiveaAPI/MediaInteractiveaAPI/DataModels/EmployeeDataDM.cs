﻿using System.Collections.Generic;
namespace MediaInteractiveaAPI.Services.DataModels
{
    public class EmployeeDataDM
    {
        public int EmpId { get; set; }
        public string Name { get; set; }
        public string Lastname { get; set; }
        public string PetName { get; set; }
        public string TypeOfAnimal { get; set; }
        public string IsMediaInteractivaEmp { get; set; }
        public string Ownername { get; set; }
    }
}
