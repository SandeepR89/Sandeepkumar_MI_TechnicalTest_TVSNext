﻿using MediaInteractiveaAPI.Services.ViewModels;
using MediaInteractiveaAPI.Services.DataModels;
using System.Collections.Generic;

namespace MediaInteractiveaAPI.Services.Services
{
    public interface IEmployeeServices
    {
        List<EmployeeDataDM> GetAllEmployee(out int status);
    }
}
