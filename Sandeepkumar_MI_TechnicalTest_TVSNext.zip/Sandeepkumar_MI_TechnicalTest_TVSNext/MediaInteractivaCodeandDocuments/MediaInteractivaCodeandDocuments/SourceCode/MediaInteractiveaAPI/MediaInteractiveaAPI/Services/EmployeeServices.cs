﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Microsoft.Extensions.Configuration;
using AutoMapper;
using Dapper;
using MediaInteractiveaAPI.Services.Common;
using MediaInteractiveaAPI.Services.DataModels;
using MediaInteractiveaAPI.Services.ViewModels;

namespace MediaInteractiveaAPI.Services.Services
{
    public class EmployeeServices:IEmployeeServices
    {
        private readonly IConfiguration _config;
        private readonly IMapper _mapper;

        public EmployeeServices(IConfiguration config, IMapper mapper)
        {
            _config = config;
            _mapper = mapper;
        }

        public IDbConnection Connection
        {
            get
            {
                return new SqlConnection(_config.GetConnectionString(Constants.databaseName));
            }
        }

       
        public List<EmployeeDataDM> GetAllEmployee(out int status)
        {
            TraceLog.LogActivity(Constants.serviceIn, null, "EmployeeService - GetAllEmployee");
            var getAllEmployeeList = new List<EmployeeDataDM>();
            try
            {
                using (IDbConnection con = Connection)
                {
                    con.Open();
                    var parameters = new DynamicParameters();
                    parameters.Add(Constants.mistatusDbParam, dbType: DbType.Int16, direction: ParameterDirection.Output, size: 1);
                    getAllEmployeeList = con.Query<EmployeeDataDM>(SPConstants.getAllEmployee, parameters, commandType: CommandType.StoredProcedure).ToList();

                    status = parameters.Get<Int16>(Constants.mistatus);
                    
                }
            }
            catch (Exception ex)
            {
                TraceLog.LogError("EmployeeService - GetAllEmployee", ex);
                status = -1;
                
            }
            TraceLog.LogActivity(Constants.serviceOut, null, "EmployeeService - GetAllEmployee");
            return getAllEmployeeList;
        }

    }
}
